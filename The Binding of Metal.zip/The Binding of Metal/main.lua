local MetalMod = RegisterMod("MetalMod", 1)
local game = Game()
local Achievements = {}
local json = require("json")

function MetalMod.onStart()
	Achievements = json.decode(MetalMod:LoadData())
	if Achievements.CollectorsCoin == nil then Achievements.CollectorsCoin = false end
	if Achievements.BanHammer == nil then Achievements.BanHammer = false end
	if Achievements.ChemicalX == nil then Achievements.ChemicalX = false end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onStart)

function MetalMod.onExit(save)
	MetalMod:SaveData(json.encode(Achievements))
end

MetalMod:AddCallback(ModCallbacks.MC_PRE_GAME_EXIT, MetalMod.onExit)
MetalMod:AddCallback(ModCallbacks.MC_POST_GAME_END, MetalMod.onExit)

function MetalMod:OnCommand(command, args)
	if command == "MetalReset" then
		print("Removed All Achievements")
		Achievements.CollectorsCoin = false
		Achievements.BanHammer = false
		Achievements.ChemicalX = false
	elseif command == "MetalUnlock" then
		print("Unlocked All Achievements")
		Achievements.CollectorsCoin = true
		Achievements.BanHammer = true
		Achievements.ChemicalX = true
	elseif command == "AchievementStates" then
		print("Achievement States")
		print(Achievements.CollectorsCoin)
		print(Achievements.BanHammer)
		print(Achievements.ChemicalX)
    end
end
MetalMod:AddCallback(ModCallbacks.MC_EXECUTE_CMD, MetalMod.OnCommand)


-- Unlocks
function MetalMod.onMomDie()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.CollectorsCoin == false then
				Achievements.CollectorsCoin = true
				Game():GetHUD():ShowFortuneText("Collectors Coin Has Appeared In The Basement.")
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onMomDie, EntityType.ENTITY_MOM)

function MetalMod.onMegaSatanDie()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.BanHammer == false then
				Achievements.BanHammer = true
				Game():GetHUD():ShowFortuneText("The Ban Hammer Has Appeared In The Basement.")
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onMegaSatanDie, EntityType.ENTITY_MEGA_SATAN)

function MetalMod.on5SoulHearts()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.CollectorsCoin == false then
				if player:GetSoulHearts() >= 10 then
					Achievements.ChemicalX = true
					Game():GetHUD():ShowFortuneText("Chemical X Has Appeared In The Basement.")
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.on5SoulHearts)


-- If Not Unlocked, Remove

local collectors_coin_item = Isaac.GetItemIdByName("Collector's Coin")

function MetalMod.AchieveCheck()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.CollectorsCoin == false then
				local room = Game():GetRoom()
				local entCoin = Isaac.FindByType(5, 100, collectors_coin_item)
				for i=1, #entCoin do
					local posCoin = entCoin[i].Position
					entCoin[i]:Remove()
					if room:GetType() ~= RoomType.ROOM_SHOP then
						Isaac.Spawn(5, 100, 0, posCoin, Vector(0,0), player)
					elseif room:GetType() ~= RoomType.ROOM_DEVIL then
						local spawnItem = Isaac.Spawn(5,100,0, posCoin, Vector(0,0), nil):ToPickup()
						spawnItem.Price = -1
						spawnItem.AutoUpdatePrice = false
						local data = spawnItem:GetData()
						data.Price = -1
						data.AutoUpdatePrice = false
					else
						local spawnItem = Isaac.Spawn(5,100,0, posCoin, Vector(0,0), nil):ToPickup()
						spawnItem.Price = 15
						spawnItem.AutoUpdatePrice = false
						local data = spawnItem:GetData()
						data.Price = 15
						data.AutoUpdatePrice = false
					end
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck)

local ban_hammer_item = Isaac.GetItemIdByName("Ban Hammer")

function MetalMod.AchieveCheck2()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.BanHammer == false then
				local room = Game():GetRoom()
				local entHammer = Isaac.FindByType(5, 100, ban_hammer_item)
				for i=1, #entHammer do
					local posHammer = entHammer[i].Position
					entHammer[i]:Remove()
					if room:GetType() ~= RoomType.ROOM_SHOP then
						Isaac.Spawn(5, 100, 0, posHammer, Vector(0,0), player)
					elseif room:GetType() ~= RoomType.ROOM_DEVIL then
						local spawnItem = Isaac.Spawn(5,100,0, posHammer, Vector(0,0), nil):ToPickup()
						spawnItem.Price = -1
						spawnItem.AutoUpdatePrice = false
						local data = spawnItem:GetData()
						data.Price = -1
						data.AutoUpdatePrice = false
					else
						local spawnItem = Isaac.Spawn(5,100,0, posHammer, Vector(0,0), nil):ToPickup()
						spawnItem.Price = 15
						spawnItem.AutoUpdatePrice = false
						local data = spawnItem:GetData()
						data.Price = 15
						data.AutoUpdatePrice = false
					end
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck2)

local chemical_x_item = Isaac.GetItemIdByName("Chemical X")

function MetalMod.AchieveCheck3()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.ChemicalX == false then
				local room = Game():GetRoom()
				local entChem = Isaac.FindByType(5, 100, chemical_x_item)
				for i=1, #entChem do
					local posChem = entChem[i].Position
					entChem[i]:Remove()
					if room:GetType() ~= RoomType.ROOM_SHOP then
						Isaac.Spawn(5, 100, 0, posChem, Vector(0,0), player)
					elseif room:GetType() ~= RoomType.ROOM_DEVIL then
						local spawnItem = Isaac.Spawn(5,100,0, posChem, Vector(0,0), nil):ToPickup()
						spawnItem.Price = -1
						spawnItem.AutoUpdatePrice = false
						local data = spawnItem:GetData()
						data.Price = -1
						data.AutoUpdatePrice = false
					else
						local spawnItem = Isaac.Spawn(5,100,0, posChem, Vector(0,0), nil):ToPickup()
						spawnItem.Price = 15
						spawnItem.AutoUpdatePrice = false
						local data = spawnItem:GetData()
						data.Price = 15
						data.AutoUpdatePrice = false
					end
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck3)




 -- else
local IsDead = {
	Yes = 0
}

function MetalMod:onCache(player, cacheFlag)
	if player:GetName() == "Metal" then
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = player.Damage + 0.7
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			player.MaxFireDelay = player.MaxFireDelay + 1.5
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			player.TearRange = player.TearRange - 175
		end
	end
end

local MetalChar = Isaac.GetPlayerTypeByName("Metal");

function MetalMod:MC_POST_NEW_LEVEL()
	local player = Isaac.GetPlayer(0)
	local room = Game():GetRoom()
	if Game():GetLevel():GetStage() == 1 then
		if player:GetName() == "Metal" then
			IsDead.Yes = 0
			local mycostume = Isaac.GetCostumeIdByPath("gfx/characters/Metal_Hair.anm2")
			if player:GetPlayerType() == MetalChar then
				player:AddNullCostume(mycostume)
			end
			player:SetPocketActiveItem(Isaac.GetItemIdByName("Metal D6"), ActiveSlot.SLOT_POCKET, false)
		end
	end
end

function MetalMod.onDamage(tookDamage, damageAmount, damageFlags, damageSource, damageCountdownFrames)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:GetName() == "Metal" then
			print(IsDead.Yes)
			if math.random(1,10) == 1 then
				Game():GetHUD():ShowItemText("Skill Issue.")
			end
		end
	end
end



function MetalMod.onDeath()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if IsDead.Yes == 0 then
				print(IsDead.Yes)
				player:Revive()
				player:AddMaxHearts(24)
				player:AddMaxHearts(-22)
				player:AddBlackHearts(6)
				player:AddMaxHearts(-2)
				player:AddBrokenHearts(9)
				Isaac.Spawn(5, 100, CollectibleType.COLLECTIBLE_MYSTERY_GIFT, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Isaac.Spawn(5, 40, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Isaac.Spawn(5, 30, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Isaac.Spawn(5, 20, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Game():GetHUD():ShowFortuneText("Dont die again.")
				
				IsDead.Yes = 1
			end
		end
	end
end

function MetalMod.onUpdate()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			local room = Game():GetRoom()
			local ent = Isaac.FindByType(1000, 14)
			for i=1, #ent do
				local pos = ent[i].Position
				Isaac.Spawn(1000, 44, 0, pos, Vector(0,0), player)
			end
		end
	end
end

local MetalD6Id = {
	Isaac.GetItemIdByName("Metal D6")
}

function MetalMod.onFireTear(_, tear)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			tear.TearFlags = tear.TearFlags | TearFlags.TEAR_HYDROBOUNCE
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_FIRE_TEAR, MetalMod.onFireTear)

function MetalMod:update()
	local entities = Isaac.GetRoomEntities()
	for i = 1, #entities do
		local e = entities[i]
		if e.Type == 5 and e.Variant == 100 and e.SubType == 0 then
			e:Remove()
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE , MetalMod.update);

function MetalMod:use_MetalMod(itemUsed)
	if itemUsed == MetalD6Id[1] then
		local player = Isaac.GetPlayer(0)
		if player == nil then return false end
		local room = Game():GetRoom()
		if room:GetType() ~= RoomType.ROOM_SHOP
		and room:GetType() ~= RoomType.ROOM_DEVIL then
			local ent = Isaac.FindByType(5, 100, -1)
			for i=1, #ent do
				local pos = ent[i].Position
				ent[i]:Remove()
				Isaac.Spawn(5,100,CollectibleType.COLLECTIBLE_IRON_BAR, pos, Vector(0,0), player)
			end
		end
		if room:GetType() == RoomType.ROOM_SHOP then
			local ent2 = Isaac.FindByType(5, 100, -1)
			for i=1, #ent2 do
				local pos2 = ent2[i].Position
				ent2[i]:Remove()
				local spawnItem = Isaac.Spawn(5, 100, CollectibleType.COLLECTIBLE_IRON_BAR, pos2,Vector(0,0), player):ToPickup()
				spawnItem.Price = 15
				spawnItem.AutoUpdatePrice = false
				local data = spawnItem:GetData()
				data.Price = 15
			end
		end
		if room:GetType() == RoomType.ROOM_DEVIL then
			local ent2 = Isaac.FindByType(5, 100, -1)
			for i=1, #ent2 do
				local pos2 = ent2[i].Position
				ent2[i]:Remove()
				local spawnItem = Isaac.Spawn(5, 100, CollectibleType.COLLECTIBLE_IRON_BAR, pos2,Vector(0,0), player):ToPickup()
				spawnItem.Price = -1
				spawnItem.AutoUpdatePrice = false
				local data = spawnItem:GetData()
				data.Price = -1
			end
		end
		return {
		ShowAnim = true
		}
	end
end
MetalMod:AddCallback( ModCallbacks.MC_USE_ITEM, MetalMod.use_MetalMod );

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)
MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onDeath, EntityType.ENTITY_PLAYER)
MetalMod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG,MetalMod.onDamage, EntityType.ENTITY_PLAYER)
MetalMod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, MetalMod.MC_POST_NEW_LEVEL)
MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)


-- Collectors Coin
local game = Game()

local MetalModId2 = {
	COLLECTORS_COIN = Isaac.GetItemIdByName("Collector's Coin")
}

local HasMetalMod2 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod2 = player:HasCollectible(MetalModId2.COLLECTORS_COIN)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.Luck = player.Luck + 3
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_COLLECTORS_COIN = Isaac.GetItemIdByName("Collector's Coin")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod2 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_COLLECTORS_COIN) then
			if not MetalMod.HasMetalMod2 then
				player:AddCoins(1)
				MetalMod.HasMetalMod2 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- The Feet XD
local game = Game()

local MetalModId3 = {
	THE_FEET = Isaac.GetItemIdByName("The Feet")
}

local HasMetalMod3 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod3 = player:HasCollectible(MetalModId3.THE_FEET)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.25
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_THE_FEET = Isaac.GetItemIdByName("The Feet")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod3 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_THE_FEET) then
			if not MetalMod.HasMetalMod3 then
				MetalMod.HasMetalMod3 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Chemical X
local game = Game()

local MetalModId4 = {
	CHEMICAL_X = Isaac.GetItemIdByName("Chemical X")
}

local HasMetalMod4 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod4 = player:HasCollectible(MetalModId4.CHEMICAL_X)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.Damage = player.Damage + 1.5
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.10
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FLYING then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.CanFly = true
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_CHEMICAL_X = Isaac.GetItemIdByName("Chemical X")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod4 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_CHEMICAL_X) then
			if not MetalMod.HasMetalMod4 then
				MetalMod.HasMetalMod4 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Ban Hammer
local game = Game()

local MetalModId5 = {
	BAN_HAMMER = Isaac.GetItemIdByName("Ban Hammer")
}

local HasMetalMod5 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod5 = player:HasCollectible(MetalModId5.BAN_HAMMER)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.Damage = player.Damage * 1.15
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_BAN_HAMMER = Isaac.GetItemIdByName("Ban Hammer")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod5 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_BAN_HAMMER) then
			if not MetalMod.HasMetalMod5 then
				MetalMod.HasMetalMod5 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId6 = {
	DOCTOR_BANANA = Isaac.GetItemIdByName("Dr. Banana")
}

local HasMetalMod6 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod6 = player:HasCollectible(MetalModId6.DOCTOR_BANANA)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.Damage = player.Damage * 1.25
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.Luck = player.Luck + 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.10
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_DOCTOR_BANANA = Isaac.GetItemIdByName("Dr. Banana")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod6 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_DOCTOR_BANANA) then
			if not MetalMod.HasMetalMod6 then
				player:AddMaxHearts(2)
				player:AddHearts(4)
				player:AddSoulHearts(2)
				MetalMod.HasMetalMod6 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

